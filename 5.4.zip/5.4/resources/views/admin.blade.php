<html>
<head>
<title>cafe Zombies</title>

<link rel="stylesheet" type= "text/css" href="css.css">

<style>
a
{
text-decoration:none;
}
body 
{
	background-color: #E7E2CF;
}

.style1 
{
	font-size: 40px
}
.style2 {color: #39578B}

 #mainContent .postGrid{
         list-style-type: none;
         display: block;
         width: 300px;
         height: 510px;
         float: left;
         /*border-bottom: 1px dashed #cecec2;*/
         padding:5px 15px;
         color: #363231;
         overflow: hidden;
      

</style>

</head>
<body>
	<center><br><h1 class="style1 style2">CAFE ZOMBIES</h1></center><br><br>
	 <center><img src="larry.gif"></td>

<table width="1008" height="69" border="0" align="center">
  <tr>
    <td width="116"><img src="menu-left.png" width="120" height="65"></td>
      <td width="116"><img src="coffee.jpg" width="120" height="65"></td>
	<td bgcolor="000000"><div align="center"><font size="4.5">
    <a href="admin">HOME</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="food">FOOD</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="minum">DRINKS</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="tentang">ABOUT</a>&nbsp;&nbsp;&nbsp;&nbsp;
    </font>
      <td width="116"><img src="coffee.jpg" width="120" height="65"></td>
	</div>
	</td>
    <td width="122"><img src="menu-right.png" width="120" height="65" ></td>
  </tr>
</table>
        
            </div> <!-- akhir sidebar -->

            <div id="mainContent">
            	
            		<div class="postGrid">
                  <div class="meta">
                    <div class="tanggal">
                      <span class="bulan"><div></div></span>
                    </div>
                    
                  </div>

                  
                  <h3>Cafe Zombies</h3>
				<tr>  
                <td width="122"><img src="kopi.jpg" width="300" height="200" ></td>
				Resto dan Coffee House pastinya sudah benyak berdiri di kawasan Kota Malang dan sekitarnya. Namun satu cafe dengan cafe lainnya 
			   pasti memiliki perbedaan disegi fasilitas dan pelayanan yang diberikan. Tidak salah jika banyak cafe di Kota Malang menyajikan 
			   beragam fasilitas exclusive dan unggul agar dapat bersaing dengan cafe lainnya untuk menarik hati para pengunjung dan wisatawan. 
			   Salah satu Cafe dan Resto di Kota Malang yang menawarkan beragam fasilitas menarik adalah Ria Djenaka Coffee & Resto ini. </div>
				</tr>
            		<div class="postGrid last">
                  <div class="meta">
                    <div class="tanggal">
					</div>
                    
                  </div>
                  <h3>Cafe Zombies</h3>
                  <td width="122"><img src="coffee.jpg" width="300" height="200" ></td>
                  sini Anda bisa menikmati beragam kuliner baik masakan maupun minuman yang pastinya siap memuaskan Anda selama berada 
				  diCafe Zombies Malang ini. Menu sajian yang ditawarkan beragam, mulai dari sajian tradisional hingga 
				  Internasional dapat Anda temukan dengan mudah di cafe yang satu ini. Adapun beberpa snack serta jajanan ringan lainnya
				  di Cafe Zombies ini, antara lain seperti Roti Petruk, Singkong Keju, Srikandi
				  , Rama Shinta, Zupa-Zupa, Tahu Genjrot, Bakmi Singapore dan masih banyak lainnya menu main course lainnya.</div>
                </tr>
                <div class="separator"></div>

            		<div class="postGrid">
                  <div class="meta">
                    <div class="tanggal">
               
                  </div>
                    
                  </div>

                  
                  <h3>Cafe Zombies</h3>
                  <td width="122"><img src="musik.jpg" width="300" height="200" ></td>
                 Selain menu menu ringan tersebut, tidak ketinggalan sajian unggulan Coffe yang memang menjadi sajian primadona di Cafe Zombies
				 Coffee & Resto ini. Terdapat beragam varian Coffe yang ditawarkan resto ini mulai dari Arabica Java, Toraja atau Aceh Gayo, 
				 Coffee Collin�, Capuccino Choco Chips, Ice Coffee Orange, Hot Coffee Orang, Lampung Coffe, White Hazelnut dsb. Dengan ditemani 
				 suasana tempoe doeloe ala Ria Djenaka dan Free Wi-Fi membuat sensasi nongkrong Anda lebih santai dan nyaman. Di Cafe Zombies
				 ini juga terdapat live music </div>
				</tr>
            		<div class="postGrid last">
                  <div class="meta">
                    <div class="tanggal">
                    </div>
                    
                  </div>
                  <h3>Cafe Zombies</h3>
				  <td width="122"><img src="depan.jpg" width="300" height="200" ></td>
				  performence yang mengusung musik akustik dan tembang klasik setiap malamnya.
                 Di Cafe Zombies ini juga terdapat live music performence yang mengusung musik akustik dan tembang klasik setiap malamnya. </div>
				</tr>
                <div class="separator"></div>
            </div> <!-- akhir mainContent -->


</body>
</html>
