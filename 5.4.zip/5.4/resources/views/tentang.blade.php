<html>
<head>
<title>cafe Zombies</title>

<link rel="stylesheet" type= "text/css" href="css.css">

<style>
a
{
text-decoration:none;
}
body 
{
	background-color: #E7E2CF;
}

.style1 
{
	font-size: 40px
}
.style2 {color: #39578B}

 #mainContent .postGrid{
         list-style-type: none;
         display: block;
         width: 300px;
         height: 510px;
         float: left;
         /*border-bottom: 1px dashed #cecec2;*/
         padding:5px 15px;
         color: #363231;
         overflow: hidden;
      

</style>

</head>
<body>
	<center><br><h1 class="style1 style2">CAFE ZOMBIES</h1></center><br><br>
	 <center><img src="larry.gif"></td>

<table width="1008" height="69" border="0" align="center">
  <tr>
    <td width="116"><img src="menu-left.png" width="120" height="65"></td>
      <td width="116"><img src="coffee.jpg" width="120" height="65"></td>
	<td bgcolor="000000"><div align="center"><font size="4.5">
    <a href="admin">HOME</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="food">FOOD</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="minum">DRINKS</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="tentang">ABOUT</a>&nbsp;&nbsp;&nbsp;&nbsp;
    </font>
      <td width="116"><img src="coffee.jpg" width="120" height="65"></td>
	</div>
	</td>
    <td width="122"><img src="menu-right.png" width="120" height="65" ></td>
  </tr>
</table>
        
            </div> <!-- akhir sidebar -->

            <div id="mainContent">
            	
            		<div class="postGrid">
                  <div class="meta">
                    <div class="tanggal">
                      <span class="bulan"><div></div></span>
				<tr>  
				BY: AGASTA LIANDY </div>
				</tr>
            		<div class="postGrid last">
                  <div class="meta">
                    <div class="tanggal">
					</div>
                
				</tr>
                <div class="separator"></div>
            </div> <!-- akhir mainContent -->


</body>
</html>
